import React, { useState, useEffect } from 'react';
import { View, Text, Image, TouchableOpacity, ScrollView, TextInput, ActivityIndicator, Share } from 'react-native';
import { Audio } from 'expo-av';
import { FontAwesome, Entypo, Feather, Ionicons } from '@expo/vector-icons';
// import { classnames } from 'nativewind';
import axios from 'axios';
import { AntDesign } from '@expo/vector-icons';
const mockData = {
    blog: {
        id: '1',
        category: 'Top Stories',
        title: 'No Government Servant Can Claim Promotion As Their Right: Supreme Court',
        author: 'Anmol Kaur Bawa',
        date: '2024-06-01T12:33:00Z',
        coverImage: 'https://arihantai.com/web/image/website/1/logo/Arihant%20AI?unique=cfc2f62',
        audioUrl: 'https://commondatastorage.googleapis.com/codeskulptor-demos/DDR_assets/Kangaroo_MusiQue_-_The_Neverwritten_Role_Playing_Game.mp3',
        description: 'Recently, the Supreme Court observed that government employees cannot demand promotion as a matter of right and that the Court\'s intervention in promotion policies should only be limited when there is a violation of the equality principle under Article 16 of the constitution.Recently, the Supreme Court observed that government employees cannot demand promotion as a matter of right and that the Court\'s intervention in promotion policies should only be limited when there is a violation of the equality principle under Article 16 of the constitution'
    }
};

const BlogScreen = () => {
    const [blog, setBlog] = useState(null);
    const [loading, setLoading] = useState(true);
    const [sound, setSound] = useState();
    const [playing, setPlaying] = useState(false);

    useEffect(() => {
        fetchBlog();
    }, []);

    const fetchBlog = async () => {
        try {
            // Replace with actual API call
            // const response = await axios.get('https://example.com/api/blog');
            // setBlog(response.data.blog);
            setBlog(mockData.blog);  // Using mock data for testing
            setLoading(false);
        } catch (error) {
            console.error(error);
            setLoading(false);
        }
    };

    const formatDate = (dateString) => {
        const options = { hour: '2-digit', minute: '2-digit', year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString(undefined, options);
    };

    const playPauseAudio = async () => {
        if (playing) {
            await sound.pauseAsync();
            setPlaying(false);
        } else {
            const { sound: newSound } = await Audio.Sound.createAsync({ uri: blog.audioUrl });
            setSound(newSound);
            await newSound.playAsync();
            setPlaying(true);
        }
    };

    const shareBlog = async () => {
      try {
        await Share.share({
            message: `${blog.title} - ${blog.description}`,
            url: blog.coverImage
        });
    } catch (error) {
        alert(error.message);
    }
};

    if (loading) {
        return (
            <View className="flex-1 justify-center items-center">
                <ActivityIndicator size="large" color="#E10600" />
            </View>
        );
    }

    return (
        <ScrollView className="flex-1 bg-white">
          
            <View className="p-4 mt-6">
              <View className="bg-slate-100 mb-4 h-16 w-screen right-4">
            <View className="flex-row mb-4  h-12 w-full justify-between items-center mt-4">
                    <TouchableOpacity className="mb-4 ml-4 bottom-">
                    <AntDesign name="arrowleft" size={24} color="red" />
                    </TouchableOpacity>
                    <Text className="text-red-600 font-bold text-lg bottom-2 right-2">Live Law</Text>
                    <TouchableOpacity onPress={shareBlog}  className=" bottom-2 right-4">
                        <Entypo name="share" size={24} color="red" />
                    </TouchableOpacity>
                </View>
                </View>
                <Image source={{ uri: blog.coverImage }} className="w-full h-52 mb-2 mt-2" />
                <Text className="bg-red-600 text-white w-28 p-2 rounded-md text-center mt-4 font-bold mb-2">{blog.category}</Text>
                <Text className="text-lg font-bold mb-1 text-justify ml-1" >{blog.title}</Text>
                <Text className="text-base text-red-600 mb-1 font-semibold mt-4"> {blog.author}</Text>
                <Text className="text-base text-gray-800 mb-4 ml-1">{formatDate(blog.date)}</Text>
                <View className="bg-slate-200 rounded-md mt-4 mb-6 ml-2 mr-2">
                <Text className="text-base font-bold mb-2 ml-3 mt-2">Listen to this Article</Text>
                <TouchableOpacity onPress={playPauseAudio} className="flex-row ml-3 items-center mb-4">
                    <FontAwesome name={playing ? 'pause' : 'play'} size={18} color="black" />
                    <Text className="ml-2">{playing ? 'Pause' : 'Play'} Audio</Text>
                </TouchableOpacity>
                </View>
                <Text className="text-lg ml-2 mr-2 mb-4 text-justify" >{blog.description}</Text>

               
            </View>
        </ScrollView>
    );
};

export default BlogScreen;